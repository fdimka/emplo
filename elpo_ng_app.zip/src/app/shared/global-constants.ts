import { environment } from 'src/environments/environment';

export const GLOBAL_CONST = {
  BACKEND_URL_EMPLOYEES: environment.apiUrl + '/employees/',
  BACKEND_URL_USERS: environment.apiUrl + '/user/',
  // Header component
  APP_TITLE: 'EMPLO',
  HEADER_LIST_NAME_TXT: 'Employees List',
  HEADER_ADD_NEW_ELM_NAME_TXT: 'Add New Employee',
  HEADER_TAB_ACTION_LOGIN_TXT: 'Login',
  HEADER_TAB_ACTION_LOGOUT_TXT: 'Logout',
  HEADER_TAB_ACTION_SIGNUP_TXT: 'Signup',
  // button action name text
  BTN_SAVE: 'Save',
  BTN_EDIT: 'Edit',
  BTN_REMOVE: 'Remove'
};
