import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { GLOBAL_CONST } from '../shared/global-constants';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnDestroy {

  appTitle = GLOBAL_CONST.APP_TITLE;
  tabActionShowListName = GLOBAL_CONST.HEADER_LIST_NAME_TXT;
  tabActionaddElm = GLOBAL_CONST.HEADER_ADD_NEW_ELM_NAME_TXT;
  tabActionLogin = GLOBAL_CONST.HEADER_TAB_ACTION_LOGIN_TXT;
  tabActionLogout = GLOBAL_CONST.HEADER_TAB_ACTION_LOGOUT_TXT;
  tabActionSignup = GLOBAL_CONST.HEADER_TAB_ACTION_SIGNUP_TXT;
  userIsAuthenticated = false;

  private authListenerSub$: Subscription;

  constructor(private authService: AuthService) { }

  ngOnInit(): void {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authListenerSub$ = this.authService.getAuthStatusListener()
      .subscribe(isAithrnticated => {
        this.userIsAuthenticated = isAithrnticated;
      });
  }

  onLogout(): void {
    this.authService.logoutUser();
  }

  ngOnDestroy(): void {
    this.authListenerSub$.unsubscribe();
  }

}
