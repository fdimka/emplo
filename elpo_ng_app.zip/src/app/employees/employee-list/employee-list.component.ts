import { Component, OnDestroy, OnInit } from '@angular/core';
import { Employee } from '../employee.model';
import { EmployeesService } from '../employees.service';
import { Subscription } from 'rxjs';
import { PageEvent } from '@angular/material/paginator';
import { AuthService } from 'src/app/auth/auth.service';
import { GLOBAL_CONST } from '../../shared/global-constants';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.scss']
})
export class EmployeeListComponent implements OnInit, OnDestroy {

  employees: Employee[] = [];
  isLoading = false;
  totalEmployees = 10;
  employeePerPage = 10;
  currentPage = 1;
  pageSizeOptions = [1, 2, 5, 10];
  userIsAuthenticated = false;
  editBtnName = GLOBAL_CONST.BTN_EDIT;
  removeBtnName = GLOBAL_CONST.BTN_REMOVE;
  userId: string;

  private employeeSub$: Subscription;
  private authListenerSub$: Subscription;


  constructor(public employeesService: EmployeesService,
              private authService: AuthService) { }

  ngOnInit(): void {
    this.isLoading = true;
    this.employeesService.getEmployees(this.employeePerPage, this.currentPage);

    this.userId = this.authService.getUserId();
    this.employeeSub$ = this.employeesService.getEmployeeUpdatedistener()
      .subscribe((employeerData: { employees: Employee[], employeeCount: number }) => {
        this.isLoading = false;
        this.totalEmployees = employeerData.employeeCount;
        this.employees = employeerData.employees;
      });

    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authListenerSub$ = this.authService.getAuthStatusListener()
       .subscribe(isAithrnticated => {
         this.userIsAuthenticated = isAithrnticated;
         this.userId = this.authService.getUserId();
       });
  }

  removeEmployee(employeeId: string): void {
    this.isLoading = true;
    this.employeesService.deleteEmployee(employeeId)
      .subscribe(() => {
        this.employeesService.getEmployees(this.employeePerPage, this.currentPage);
      }, () => {
        this.isLoading = false;
      });
  }

  changePage(pageData: PageEvent): void {
    this.isLoading = true;
    this.currentPage = pageData.pageIndex + 1;
    this.employeePerPage = pageData.pageSize;
    this.employeesService.getEmployees(this.employeePerPage, this.currentPage);
  }

  ngOnDestroy(): void {
    this.employeeSub$.unsubscribe();
    this.authListenerSub$.unsubscribe();
  }

}
