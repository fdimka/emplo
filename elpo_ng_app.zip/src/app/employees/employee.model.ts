export interface Employee {
  id: string;
  firstName: string;
  lastName: string;
  position: string;
  department: string;
  imagePath: string;
  creator: string;
}
