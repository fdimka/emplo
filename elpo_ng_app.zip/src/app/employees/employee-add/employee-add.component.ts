import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { EmployeesService } from '../employees.service';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Employee } from '../employee.model';
import { Subscription } from 'rxjs';
import { mineType } from '../../shared/mime-type.validator';
import { AuthService } from 'src/app/auth/auth.service';
import { GLOBAL_CONST } from 'src/app/shared/global-constants';

@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.scss']
})
export class EmployeeAddComponent implements OnInit, OnDestroy {

  employee: Employee;
  isLoading = false;
  form: FormGroup;
  saveBtnName = GLOBAL_CONST.BTN_SAVE;
  imagePreview: string;

  private mode = 'create';
  private employeeId: string;

  private authStatusSub$: Subscription;

  constructor(private employeesService: EmployeesService,
              private route: ActivatedRoute,
              private authService: AuthService) { }

  ngOnInit(): void {
    this.authStatusSub$ = this.authService.getAuthStatusListener()
      .subscribe(authStatus => {
        this.isLoading = false;
      });

    this.form = new FormGroup({
      firstName: new FormControl(null, { validators: [Validators.required, Validators.minLength(2)] }),
      lastName: new FormControl(null, { validators: [Validators.required, Validators.minLength(1)] }),
      position: new FormControl(null, { validators: [Validators.required, Validators.maxLength(22)] }),
      department: new FormControl(null, { validators: [Validators.required] }),
      image: new FormControl(null, { validators: [Validators.required], asyncValidators: [mineType] }),
    });

    this.route.paramMap.subscribe((paramMap: ParamMap) => {
      if (paramMap.has('employeeId')) {
        this.mode = 'edit';
        this.employeeId = paramMap.get('employeeId');
        this.isLoading = true;
        this.employeesService.getEmployee(this.employeeId)
          .subscribe(employeeData => {
            this.isLoading = false;
            this.employee = {
              id: employeeData._id,
              firstName: employeeData.firstName,
              lastName: employeeData.lastName,
              position: employeeData.position,
              department: employeeData.department,
              imagePath: employeeData.imagePath,
              creator: employeeData.creator
            };
            this.form.setValue({
              firstName: this.employee.firstName,
              lastName: this.employee.lastName,
              position: this.employee.position,
              department: this.employee.department,
              image: this.employee.imagePath
            });
          });
      } else {
        this.mode = 'create';
        this.employeeId = null;
      }
    });
  }

  addNewEmployee(): void {
    if (this.form.invalid) {
      return;
    }
    this.isLoading = true;
    if (this.mode === 'create') {
      this.employeesService.addEmployee(
        this.form.value.firstName,
        this.form.value.lastName,
        this.form.value.position,
        this.form.value.department,
        this.form.value.image);
    } else {
      this.employeesService.updateEmployee(
        this.employeeId,
        this.form.value.firstName,
        this.form.value.lastName,
        this.form.value.position,
        this.form.value.department,
        this.form.value.image);
    }

    this.form.reset();
  }

  uploadPhoto(event: Event): void {
    const file = (event.target as HTMLInputElement).files[0];
    this.form.patchValue({ image: file });
    this.form.get('image').updateValueAndValidity();
    const reader = new FileReader();
    reader.onload = () => {
      this.imagePreview = reader.result as string;
    };
    reader.readAsDataURL(file);
  }

  ngOnDestroy(): void {
    this.authStatusSub$.unsubscribe();
  }

}
