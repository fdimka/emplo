import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subject} from 'rxjs';
import { map } from 'rxjs/operators';
import { GLOBAL_CONST } from '../shared/global-constants';
import { Employee } from './employee.model';

@Injectable({
  providedIn: 'root'
})
export class EmployeesService {

  private employees: Employee[] = [];
  private employeesUpdated = new Subject<{ employees: Employee[]; employeeCount: number }>();

  constructor(private http: HttpClient, private router: Router) { }

  getEmployee(id: string): Observable<{ _id: string; firstName: string; lastName:
              string; position: string; department: string; imagePath: string; creator: string; }> {
    return this.http.get<{
      _id: string,
      firstName: string,
      lastName: string,
      position: string,
      department: string,
      imagePath: string,
      creator: string
    }>(
      GLOBAL_CONST.BACKEND_URL_EMPLOYEES + id
    );
  }

  getEmployees(employeesPerPage: number, currentPage: number): void {
    const queryParams = `?pagesize=${employeesPerPage}&page=${currentPage}`;
    this.http.get<{ message: string, employees: any, maxEmployees: number }>(GLOBAL_CONST.BACKEND_URL_EMPLOYEES + queryParams)
      .pipe(map((employeerData => {
        return {
          employees: employeerData.employees.map(employee => {
            return {
              id: employee._id,
              firstName: employee.firstName,
              lastName: employee.lastName,
              position: employee.position,
              department: employee.department,
              imagePath: employee.imagePath,
              creator: employee.creator
            };
          }),
          maxEmployees: employeerData.maxEmployees
        };
      })))
      .subscribe((transformedEmployeeData) => {
        this.employees = transformedEmployeeData.employees;
        this.employeesUpdated.next({ employees: [...this.employees], employeeCount: transformedEmployeeData.maxEmployees });
      });
  }

  getEmployeeUpdatedistener(): Observable<{employees: Employee[]; employeeCount: number; }> {
    return this.employeesUpdated.asObservable();
  }

  addEmployee(firstName: string, lastName: string, position: string, department: string, image: File): void {
    const employeeData = new FormData();
    employeeData.append('firstName', firstName);
    employeeData.append('lastName', lastName);
    employeeData.append('position', position);
    employeeData.append('department', department);
    employeeData.append('image', image, firstName);
    this.http.post<{ message: string, employee: Employee }>(GLOBAL_CONST.BACKEND_URL_EMPLOYEES, employeeData)
      .subscribe(responseData => {
        this.router.navigate(['/']);
      });
  }

  updateEmployee(id: string, firstName: string, lastName: string, position: string, department: string, image: File | string): void {
    let employeeData: Employee | FormData;
    if (typeof (image) === 'object') {
      employeeData = new FormData();
      employeeData.append('id', id);
      employeeData.append('firstName', firstName);
      employeeData.append('lastName', lastName);
      employeeData.append('position', position);
      employeeData.append('department', department);
      employeeData.append('image', image, firstName);
    } else {
      employeeData = {
        id, firstName, lastName, position, department, imagePath: image, creator: null
      };
    }
    this.http.put(GLOBAL_CONST.BACKEND_URL_EMPLOYEES + id, employeeData)
      .subscribe(response => {
        this.router.navigate(['/']);
      });
  }

  deleteEmployee(employeeId: string): Observable<any> {
    return this.http.delete(GLOBAL_CONST.BACKEND_URL_EMPLOYEES + employeeId);
  }

}
