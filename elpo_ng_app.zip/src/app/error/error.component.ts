import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
// import { AuthService } from '../auth/auth.service';
// import { Subscription } from 'rxjs';

@Component({
  templateUrl: './error.component.html'
})

export class ErrorComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: { message: string }) {

  }
  public message = 'An uknown error occurred!';
}
