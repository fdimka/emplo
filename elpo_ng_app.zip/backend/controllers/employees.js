const Employee = require("../models/employee");

exports.addEmployee = (req, res, next) => {
  const url = req.protocol + "://" + req.get("host");
  const employee = new Employee({
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    position: req.body.position,
    department: req.body.department,
    imagePath: url + "/images/" + req.file.filename,
    creator: req.userData.userId
  });
  employee
    .save()
    .then(addEmployee => {
      res.status(201).json({
        message: "An Employee added succesfuly!",
        employee: {
          ...addEmployee,
          id: addEmployee._id
        }
      });
    })
    .catch(error => {
      res.status(500).json({ message: "Added an employee failed!" });
    });
};

exports.updateEmployee = (req, res, next) => {
  let imagePath = req.body.imagePath;
  if (req.file) {
    const url = req.protocol + "://" + req.get("host");
    imagePath = url + "/images/" + req.file.filename;
  }
  const employee = new Employee({
    _id: req.body.id,
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    position: req.body.position,
    department: req.body.department,
    imagePath: imagePath,
    creator: req.userData.userId
  });
  Employee.updateOne({ _id: req.params.id, creator: req.userData.userId }, employee)
    .then(result => {
      if (result.n > 0) {
        res.status(200).json({ message: "Update successful!" });
      } else {
        res.status(401).json({ message: "Not autorized to update!" });
      }
    })
    .catch(error => {
      res.status(500).json({ message: "Could not updated a employee!" });
    });
};

exports.fetchEmployees = (req, res, next) => {
  const pageSize = +req.query.pagesize;
  const currentPage = +req.query.page;
  const employeeQuery = Employee.find();
  let fetchedEmployees;
  if (pageSize && currentPage) {
    employeeQuery.skip(pageSize * (currentPage - 1)).limit(pageSize);
  }
  employeeQuery
    .then(documents => {
      fetchedEmployees = documents;
      return Employee.count();
    })
    .then(count => {
      res.status(200).json({
        message: "Employees fetched succesfuly!",
        employees: fetchedEmployees,
        maxEmployees: count
      });
    })
    .catch(error => {
      res.status(500).json({ message: "Fetching a employees failed!" });
    });
};

exports.fetchEmployee = (req, res, next) => {
  Employee.findById(req.params.id)
    .then(employee => {
      if (employee) {
        res.status(200).json(employee);
      } else {
        res.status(404).json({ message: "Employee not found!" });
      }
    })
    .catch(error => {
      res.status(500).json({ message: "Fetching a employee failed!" });
    });
};

exports.removeEmployee = (req, res, next) => {
  Employee.deleteOne({ _id: req.params.id, creator: req.userData.userId })
    .then(result => {
      if (result.n > 0) {
        res.status(200).json({ message: "Employee had been removed successful!" });
      } else {
        res.status(401).json({ message: "Not autorized to remove this employee!" });
      }
    })
    .catch(error => {
      res.status(500).json({ message: "Remove an employee operation failed!" });
    });
};
