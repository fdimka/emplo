const mongoose = require("mongoose");

const employeeSchema = mongoose.Schema({
  firstName: { type: String, require: true },
  lastName: { type: String, require: true },
  position: { type: String, require: true },
  department: { type: String, require: true },
  imagePath: { type: String, require: true },
  creator: { type: mongoose.Schema.Types.ObjectId, ref: "User", require: true }
});

module.exports = mongoose.model("Employee", employeeSchema);
