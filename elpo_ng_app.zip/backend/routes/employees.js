const express = require("express");
const EmployeeController = require("../controllers/employees");
const checkAuth = require("../middleware/check-auth");
const multerExtractImage = require("../middleware/multer");

const router = express.Router();

router.post("", checkAuth, multerExtractImage, EmployeeController.addEmployee);

router.put("/:id", checkAuth, multerExtractImage, EmployeeController.updateEmployee);

router.get("", EmployeeController.fetchEmployees);

router.get("/:id", EmployeeController.fetchEmployee);

router.delete("/:id", checkAuth, EmployeeController.removeEmployee);

module.exports = router;
